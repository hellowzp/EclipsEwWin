package jp.sf.amateras.htmleditor;

import org.eclipse.jface.preference.IPreferenceStore;

public interface IHTMLPreferenceContributer {

	public void initializeDefaultPreferences(IPreferenceStore store );
		
}
