package jp.sf.amateras.htmleditor.views;

import jp.sf.amateras.htmleditor.editors.HTMLSourceEditor;

public interface IPaletteTarget {
	
	public HTMLSourceEditor getPaletteTarget();
	
}
