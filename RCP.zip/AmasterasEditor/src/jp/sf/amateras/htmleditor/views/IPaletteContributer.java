package jp.sf.amateras.htmleditor.views;

public interface IPaletteContributer {
	
	public IPaletteItem[] getPaletteItems();
	
}
