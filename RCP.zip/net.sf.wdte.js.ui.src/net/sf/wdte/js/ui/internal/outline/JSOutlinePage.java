package net.sf.wdte.js.ui.internal.outline;

import net.sf.wdte.js.core.model.JSElementList;
import net.sf.wdte.js.core.parser.JSSyntaxModelFactory;
import net.sf.wdte.js.ui.model.JSNameSorter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

public class JSOutlinePage extends ContentOutlinePage
{
  protected ITextEditor editor;

  public JSOutlinePage(ITextEditor editor)
  {
    this.editor = editor;
  }

  public void createControl(Composite parent)
  {
    super.createControl(parent);
    TreeViewer viewer = getTreeViewer();
    viewer.setContentProvider(new WorkbenchContentProvider());
    viewer.setLabelProvider(new WorkbenchLabelProvider());

    viewer.setSorter(new JSNameSorter());
  }

  public void update()
  {
    IDocument document = getDocument();
    JSSyntaxModelFactory factory = JSSyntaxModelFactory.getInstance();
    JSElementList model = factory.getContentOutline(document);
    if (model != null) {
      TreeViewer viewer = getTreeViewer();
      if (viewer != null) {
        Control control = viewer.getControl();
        if ((control != null) && (!control.isDisposed())) {
          control.setRedraw(false);
          viewer.setInput(model);
          viewer.expandAll();
          control.setRedraw(true);
        }
      }
    }
  }

  private IDocument getDocument()
  {
    IDocumentProvider provider = this.editor.getDocumentProvider();
    return provider.getDocument(this.editor.getEditorInput());
  }
}