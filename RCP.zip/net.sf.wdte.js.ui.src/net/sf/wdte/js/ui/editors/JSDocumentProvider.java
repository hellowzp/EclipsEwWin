package net.sf.wdte.js.ui.editors;

import net.sf.wdte.js.core.parser.JSPartitionScanner;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.DefaultPartitioner;
import org.eclipse.ui.editors.text.FileDocumentProvider;

public class JSDocumentProvider extends FileDocumentProvider
{
  private static String[] colorTokens = { 
    "__js_comment", 
    "__js_string", 
    "__js_keyword" };

  protected IDocument createDocument(Object element)
    throws CoreException
  {
    IDocument document = super.createDocument(element);

    if (document != null) {
      IDocumentPartitioner partitioner = 
        new DefaultPartitioner(new JSPartitionScanner(), colorTokens);
      partitioner.connect(document);
      document.setDocumentPartitioner(partitioner);
    }

    return document;
  }
}