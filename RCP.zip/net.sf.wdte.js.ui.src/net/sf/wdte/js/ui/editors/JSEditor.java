package net.sf.wdte.js.ui.editors;

import net.sf.wdte.js.core.model.JSElement;
import net.sf.wdte.js.ui.internal.outline.JSOutlinePage;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

public class JSEditor extends TextEditor
  implements ISelectionChangedListener
{
  protected JSColorManager colorManager = new JSColorManager();
  protected JSOutlinePage outlinePage;
  protected JSConfiguration configuration;
  protected boolean updating = false;

  public JSEditor()
  {
    this.configuration = new JSConfiguration(this.colorManager);

    setSourceViewerConfiguration(this.configuration);
    setDocumentProvider(new JSDocumentProvider());
  }

  public void doSave(IProgressMonitor monitor)
  {
    super.doSave(monitor);

    if (this.outlinePage != null)
    {
      this.outlinePage.update();
    }
  }

  public void dispose()
  {
    this.colorManager.dispose();
    super.dispose();
  }

  public Object getAdapter(Class key)
  {
    if (key.equals(IContentOutlinePage.class)) {
      this.outlinePage = new JSOutlinePage(this);
      this.outlinePage.addSelectionChangedListener(this);
      return this.outlinePage;
    }
    return super.getAdapter(key);
  }

  public void selectionChanged(SelectionChangedEvent event)
  {
    if (event != null)
    {
      if ((event.getSelection() instanceof IStructuredSelection))
      {
        IStructuredSelection sel = (IStructuredSelection)event.getSelection();
        if (sel != null)
        {
          JSElement fe = (JSElement)sel.getFirstElement();
          if (fe != null)
          {
            selectAndReveal(fe.getStart(), fe.getLength());
          }
        }
      }
    }
  }

  protected void updateContentDependentActions()
  {
    super.updateContentDependentActions();

    if (!this.updating)
    {
      if (this.configuration.getAutomaticOutliningPreference())
      {
        if (this.outlinePage != null)
        {
          this.updating = true;

          this.outlinePage.update();
          this.updating = false;
        }
      }
    }
  }
}