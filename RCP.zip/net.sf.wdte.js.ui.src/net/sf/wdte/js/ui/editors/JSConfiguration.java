package net.sf.wdte.js.ui.editors;

import net.sf.wdte.js.core.parser.JSScanner;
import net.sf.wdte.js.core.parser.JSStringScanner;
import net.sf.wdte.js.core.parser.NonRuleBasedDamagerRepairer;
import net.sf.wdte.js.ui.JSUIPlugin;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.StringConverter;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;

public class JSConfiguration extends SourceViewerConfiguration
{
  private JSDoubleClickStrategy doubleClickStrategy;
  private JSStringScanner stringScanner;
  private JSScanner scanner;
  private JSColorManager colorManager;
  private IPreferenceStore preferences;

  public JSConfiguration(JSColorManager colorManager)
  {
    this.colorManager = colorManager;
    this.preferences = JSUIPlugin.getDefault().getPreferenceStore();
  }

  public boolean getAutomaticOutliningPreference()
  {
    return this.preferences.getBoolean("autoOutline");
  }

  protected RGB getColorPreference(String categoryColor)
  {
    String rgbString = this.preferences.getString(categoryColor);

    if (rgbString.length() <= 0)
    {
      rgbString = this.preferences.getDefaultString(categoryColor);
      if (rgbString.length() <= 0)
      {
        rgbString = "0,0,0";
      }
    }
    return StringConverter.asRGB(rgbString);
  }

  public Color getContentColor(String categoryColor)
  {
    return this.colorManager.getColor(getColorPreference(categoryColor));
  }

  public String[] getConfiguredContentTypes(ISourceViewer sourceViewer)
  {
    return new String[] { 
      "__dftl_partition_content_type", 
      "__js_comment", 
      "__js_keyword", 
      "__js_string" };
  }

  public ITextDoubleClickStrategy getDoubleClickStrategy(ISourceViewer sourceViewer, String contentType)
  {
    if (this.doubleClickStrategy == null)
    {
      this.doubleClickStrategy = new JSDoubleClickStrategy();
    }

    return this.doubleClickStrategy;
  }

  protected JSScanner getJSScanner()
  {
    if (this.scanner == null)
    {
      Color defaultColor = getContentColor("defaultColor");
      this.scanner = new JSScanner(defaultColor);
      this.scanner.setDefaultReturnToken(new Token(new TextAttribute(defaultColor)));
    }

    return this.scanner;
  }

  protected JSStringScanner getJSStringScanner()
  {
    if (this.stringScanner == null)
    {
      Color stringColor = getContentColor("stringColor");
      this.stringScanner = new JSStringScanner(stringColor);
      this.stringScanner.setDefaultReturnToken(new Token(new TextAttribute(stringColor)));
    }

    return this.stringScanner;
  }

  public IPresentationReconciler getPresentationReconciler(ISourceViewer sourceViewer)
  {
    PresentationReconciler reconciler = new PresentationReconciler();

    DefaultDamagerRepairer dr = new DefaultDamagerRepairer(getJSScanner());
    reconciler.setDamager(dr, "__dftl_partition_content_type");
    reconciler.setRepairer(dr, "__dftl_partition_content_type");

    NonRuleBasedDamagerRepairer commentRepairer = 
      new NonRuleBasedDamagerRepairer(new TextAttribute(getContentColor("commentColor")));
    reconciler.setDamager(commentRepairer, "__js_comment");
    reconciler.setRepairer(commentRepairer, "__js_comment");

    NonRuleBasedDamagerRepairer stringRepairer = 
      new NonRuleBasedDamagerRepairer(new TextAttribute(getContentColor("stringColor")));
    reconciler.setDamager(stringRepairer, "__js_string");
    reconciler.setRepairer(stringRepairer, "__js_string");

    NonRuleBasedDamagerRepairer keywordRepairer = 
      new NonRuleBasedDamagerRepairer(new TextAttribute(getContentColor("keywordColor"), null, 1));
    reconciler.setDamager(keywordRepairer, "__js_keyword");
    reconciler.setRepairer(keywordRepairer, "__js_keyword");

    return reconciler;
  }

  public IPreferenceStore getPreferences()
  {
    return this.preferences;
  }

  public void setPreferences(IPreferenceStore store)
  {
    this.preferences = store;
  }
}