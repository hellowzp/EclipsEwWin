package net.sf.wdte.js.ui.editors;

import java.net.URL;
import net.sf.wdte.js.ui.JSUIPlugin;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.osgi.framework.Bundle;

public class JSImages
{
  public static final String ICON_VAR = "global_variable.gif";
  public static final String ICON_FUNCTION = "func.gif";
  public static final String ICON_CLASS = "class_obj.gif";
  public static final String ICON_DYNAMIC_CLASS = "dyn_class_obj.gif";
  public static final String ICON_CLASS_METHOD = "class_method.gif";
  public static final String ICON_INSTANCE_METHOD = "instance_method.gif";
  public static final String ICON_CLASS_VAR = "class_variable.gif";
  public static final String ICON_INSTANCE_VAR = "instance_variable.gif";

  public static Image get(String key)
  {
    return JSUIPlugin.getDefault().getImageRegistry().get(key);
  }

  public static ImageDescriptor getDescriptor(String key)
  {
    return JSUIPlugin.getDefault().getImageRegistry().getDescriptor(key);
  }

  public static void initializeRegistry(ImageRegistry reg)
  {
    reg.put("global_variable.gif", createImageDescriptor("global_variable.gif"));
    reg.put("func.gif", createImageDescriptor("func.gif"));
    reg.put("class_obj.gif", createImageDescriptor("class_obj.gif"));
    reg.put("dyn_class_obj.gif", createImageDescriptor("dyn_class_obj.gif"));
    reg.put("class_method.gif", createImageDescriptor("class_method.gif"));
    reg.put("instance_method.gif", 
      createImageDescriptor("instance_method.gif"));
    reg.put("class_variable.gif", createImageDescriptor("class_variable.gif"));
    reg.put("instance_variable.gif", createImageDescriptor("instance_variable.gif"));
  }

  private static ImageDescriptor createImageDescriptor(String path)
  {
    try
    {
      URL url = JSUIPlugin.getDefault().getBundle()
        .getEntry("/icons/" + path);
      return ImageDescriptor.createFromURL(url); } catch (IllegalStateException localIllegalStateException) {
    }
    return ImageDescriptor.getMissingImageDescriptor();
  }
}