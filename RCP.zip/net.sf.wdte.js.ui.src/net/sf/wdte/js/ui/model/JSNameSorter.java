package net.sf.wdte.js.ui.model;

import net.sf.wdte.js.core.model.JSClassElement;
import net.sf.wdte.js.core.model.JSClassMethodElement;
import net.sf.wdte.js.core.model.JSClassVariableElement;
import net.sf.wdte.js.core.model.JSFunctionElement;
import net.sf.wdte.js.core.model.JSGlobalVariableElement;
import net.sf.wdte.js.core.model.JSInstanceMethodElement;
import net.sf.wdte.js.core.model.JSInstanceVariableElement;
import org.eclipse.jface.viewers.ViewerSorter;

public class JSNameSorter extends ViewerSorter
{
  public int category(Object element)
  {
    if ((element instanceof JSClassElement))
      return 1;
    if ((element instanceof JSFunctionElement))
      return 2;
    if ((element instanceof JSGlobalVariableElement))
      return 3;
    if ((element instanceof JSClassVariableElement))
      return 4;
    if ((element instanceof JSInstanceVariableElement))
      return 5;
    if ((element instanceof JSClassMethodElement))
      return 6;
    if ((element instanceof JSInstanceMethodElement)) {
      return 5;
    }
    return super.category(element);
  }
}