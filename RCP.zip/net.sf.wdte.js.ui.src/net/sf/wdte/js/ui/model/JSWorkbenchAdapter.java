package net.sf.wdte.js.ui.model;

import net.sf.wdte.js.core.model.JSClassElement;
import net.sf.wdte.js.core.model.JSClassMethodElement;
import net.sf.wdte.js.core.model.JSClassVariableElement;
import net.sf.wdte.js.core.model.JSElement;
import net.sf.wdte.js.core.model.JSElementList;
import net.sf.wdte.js.core.model.JSFunctionElement;
import net.sf.wdte.js.core.model.JSGlobalVariableElement;
import net.sf.wdte.js.core.model.JSInstanceMethodElement;
import net.sf.wdte.js.core.model.JSInstanceVariableElement;
import net.sf.wdte.js.ui.editors.JSImages;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.model.WorkbenchAdapter;

public class JSWorkbenchAdapter extends WorkbenchAdapter
{
  public Object[] getChildren(Object o)
  {
    if ((o instanceof JSElementList))
      return ((JSElementList)o).getChildren(null);
    if ((o instanceof JSElement)) {
      return ((JSElement)o).getChildren(null);
    }
    return super.getChildren(o);
  }

  public ImageDescriptor getImageDescriptor(Object o)
  {
    if ((o instanceof JSClassElement))
      return JSImages.getDescriptor("class_obj.gif");
    if ((o instanceof JSGlobalVariableElement))
      return JSImages.getDescriptor("global_variable.gif");
    if ((o instanceof JSFunctionElement))
      return JSImages.getDescriptor("func.gif");
    if ((o instanceof JSClassMethodElement))
      return JSImages.getDescriptor("class_method.gif");
    if ((o instanceof JSClassVariableElement))
      return JSImages.getDescriptor("class_variable.gif");
    if ((o instanceof JSInstanceMethodElement))
      return JSImages.getDescriptor("instance_method.gif");
    if ((o instanceof JSInstanceVariableElement)) {
      return JSImages.getDescriptor("instance_variable.gif");
    }
    return super.getImageDescriptor(o);
  }

  public String getLabel(Object o)
  {
    if ((o instanceof JSElement)) {
      return ((JSElement)o).getName();
    }
    return super.getLabel(o);
  }

  public Object getParent(Object o)
  {
    if ((o instanceof JSElement)) {
      return ((JSElement)o).getParent(null);
    }
    return super.getParent(o);
  }
}