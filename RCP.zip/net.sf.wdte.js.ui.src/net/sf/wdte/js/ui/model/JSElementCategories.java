package net.sf.wdte.js.ui.model;

public abstract interface JSElementCategories
{
  public static final int CLASS = 1;
  public static final int FUNCTION = 2;
  public static final int VARIABLE = 3;
  public static final int CLASS_VARIABLE = 4;
  public static final int INSTANCE_VARIABLE = 5;
  public static final int CLASS_METHOD = 6;
  public static final int INSTANCE_METHOD = 7;
}