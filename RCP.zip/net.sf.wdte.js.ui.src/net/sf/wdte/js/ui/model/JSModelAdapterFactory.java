package net.sf.wdte.js.ui.model;

import net.sf.wdte.js.core.model.JSElement;
import net.sf.wdte.js.core.model.JSElementList;
import org.eclipse.core.runtime.IAdapterFactory;
import org.eclipse.core.runtime.IAdapterManager;
import org.eclipse.ui.model.IWorkbenchAdapter;

public class JSModelAdapterFactory
  implements IAdapterFactory
{
  public static void register(IAdapterManager manager)
  {
    JSModelAdapterFactory factory = new JSModelAdapterFactory();
    manager.registerAdapters(factory, JSElement.class);
    manager.registerAdapters(factory, JSElementList.class);
  }

  public Object getAdapter(Object adaptableObject, Class adapterType)
  {
    if ((adapterType == IWorkbenchAdapter.class) && (
      ((adaptableObject instanceof JSElement)) || 
      ((adaptableObject instanceof JSElementList)))) {
      return new JSWorkbenchAdapter();
    }

    return null;
  }

  public Class[] getAdapterList()
  {
    return new Class[] { IWorkbenchAdapter.class };
  }
}