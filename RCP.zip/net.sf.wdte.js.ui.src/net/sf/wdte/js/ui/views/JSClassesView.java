package net.sf.wdte.js.ui.views;

import net.sf.wdte.js.ui.model.JSNameSorter;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.model.WorkbenchLabelProvider;
import org.eclipse.ui.part.DrillDownAdapter;
import org.eclipse.ui.part.ViewPart;

public class JSClassesView extends ViewPart
{
  private TreeViewer viewer;
  private DrillDownAdapter drillDownAdapter;
  private Action action1;
  private Action action2;
  private Action doubleClickAction;

  public void createPartControl(Composite parent)
  {
    this.viewer = 
      new TreeViewer(parent, 770);
    this.drillDownAdapter = new DrillDownAdapter(this.viewer);
    this.viewer.setContentProvider(new JSClassesViewContentProvider());
    this.viewer.setLabelProvider(new WorkbenchLabelProvider());
    this.viewer.setSorter(new JSNameSorter());
    this.viewer.setInput(ResourcesPlugin.getWorkspace());
    makeActions();
    hookContextMenu();
    hookDoubleClickAction();
    contributeToActionBars();
  }

  private void hookContextMenu()
  {
    MenuManager menuMgr = new MenuManager("#PopupMenu");
    menuMgr.setRemoveAllWhenShown(true);
    menuMgr.addMenuListener(new IMenuListener() {
      public void menuAboutToShow(IMenuManager manager) {
        JSClassesView.this.fillContextMenu(manager);
      }
    });
    Menu menu = menuMgr.createContextMenu(this.viewer.getControl());
    this.viewer.getControl().setMenu(menu);
    getSite().registerContextMenu(menuMgr, this.viewer);
  }

  private void contributeToActionBars()
  {
    IActionBars bars = getViewSite().getActionBars();
    fillLocalPullDown(bars.getMenuManager());
    fillLocalToolBar(bars.getToolBarManager());
  }

  private void fillLocalPullDown(IMenuManager manager) {
    manager.add(this.action1);
    manager.add(new Separator());
    manager.add(this.action2);
  }

  private void fillContextMenu(IMenuManager manager) {
    manager.add(this.action1);
    manager.add(this.action2);
    manager.add(new Separator());
    this.drillDownAdapter.addNavigationActions(manager);

    manager.add(new Separator("additions"));
  }

  private void fillLocalToolBar(IToolBarManager manager) {
    manager.add(this.action1);
    manager.add(this.action2);
    manager.add(new Separator());
    this.drillDownAdapter.addNavigationActions(manager);
  }

  private void makeActions() {
    this.action1 = new Action() {
      public void run() {
        JSClassesView.this.showMessage("Action 1 executed");
      }
    };
    this.action1.setText("Action 1");
    this.action1.setToolTipText("Action 1 tooltip");
    this.action1.setImageDescriptor(
      PlatformUI.getWorkbench().getSharedImages().getImageDescriptor(
      "IMG_OBJS_INFO_TSK"));

    this.action2 = new Action() {
      public void run() {
        JSClassesView.this.showMessage("Action 2 executed");
      }
    };
    this.action2.setText("Action 2");
    this.action2.setToolTipText("Action 2 tooltip");
    this.action2.setImageDescriptor(
      PlatformUI.getWorkbench().getSharedImages().getImageDescriptor(
      "IMG_OBJS_TASK_TSK"));
    this.doubleClickAction = new Action() {
      public void run() {
        ISelection selection = JSClassesView.this.viewer.getSelection();
        Object obj = 
          ((IStructuredSelection)selection).getFirstElement();
        JSClassesView.this.showMessage("Double-click detected on " + obj.toString());
      }
    };
  }

  private void hookDoubleClickAction() {
    this.viewer.addDoubleClickListener(new IDoubleClickListener() {
      public void doubleClick(DoubleClickEvent event) {
        JSClassesView.this.doubleClickAction.run();
      } } );
  }

  private void showMessage(String message) {
    MessageDialog.openInformation(
      this.viewer.getControl().getShell(), 
      "Classes", 
      message);
  }

  public void setFocus()
  {
    this.viewer.getControl().setFocus();
  }
}