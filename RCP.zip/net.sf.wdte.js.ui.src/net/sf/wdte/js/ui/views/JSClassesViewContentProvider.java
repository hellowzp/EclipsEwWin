package net.sf.wdte.js.ui.views;

import net.sf.wdte.js.core.model.JSElement;
import net.sf.wdte.js.core.model.JSElementList;
import net.sf.wdte.js.core.parser.JSSyntaxModelFactory;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

class JSClassesViewContentProvider
  implements IStructuredContentProvider, ITreeContentProvider
{
  private IWorkspace invisibleRoot;

  public void inputChanged(Viewer v, Object oldInput, Object newInput)
  {
  }

  public void dispose()
  {
  }

  public Object[] getElements(Object parent)
  {
    if (parent.equals(ResourcesPlugin.getWorkspace())) {
      if (this.invisibleRoot == null)
        this.invisibleRoot = ((IWorkspace)parent);
      return getChildren(this.invisibleRoot);
    }
    return getChildren(parent);
  }

  public Object getParent(Object child)
  {
    if ((child instanceof IProject)) {
      return ((IProject)child).getWorkspace();
    }

    if ((child instanceof JSElement)) {
      return ((JSElement)child).getParent(child);
    }
    return null;
  }

  public Object[] getChildren(Object parent)
  {
    if ((parent instanceof IWorkspace)) {
      return this.invisibleRoot.getRoot().getProjects();
    }

    if ((parent instanceof IProject)) {
      return getClasses((IProject)parent);
    }

    if ((parent instanceof JSElement)) {
      return ((JSElement)parent).getChildren(parent);
    }

    return new Object[0];
  }

  private Object[] getClasses(IProject project)
  {
    return 
      JSSyntaxModelFactory.getInstance()
      .getContentOutline(project)
      .getChildren();
  }

  public boolean hasChildren(Object parent)
  {
    return getChildren(parent).length > 0;
  }
}