package net.sf.wdte.js.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import net.sf.wdte.js.ui.editors.JSImages;
import net.sf.wdte.js.ui.model.JSModelAdapterFactory;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

public class JSUIPlugin extends AbstractUIPlugin
{
  private static JSUIPlugin plugin;
  private ResourceBundle resourceBundle;
  private List currentFunctions = new LinkedList();

  public JSUIPlugin()
  {
    plugin = this;
    try
    {
      this.resourceBundle = 
        ResourceBundle.getBundle("net.sf.wdte.js.ui.jseditorPluginResources");
    } catch (MissingResourceException localMissingResourceException) {
      this.resourceBundle = null;
    }
  }

  public static JSUIPlugin getDefault()
  {
    return plugin;
  }

  public static IWorkspace getWorkspace()
  {
    return ResourcesPlugin.getWorkspace();
  }

  public static String getResourceString(String key)
  {
    ResourceBundle bundle = getDefault().getResourceBundle();
    try {
      return bundle.getString(key); } catch (MissingResourceException localMissingResourceException) {
    }
    return key;
  }

  public ResourceBundle getResourceBundle()
  {
    return this.resourceBundle;
  }

  public List getCurrentFunctions()
  {
    return this.currentFunctions;
  }

  public void setCurrentFunctions(List currentFunctions)
  {
    this.currentFunctions = currentFunctions;
  }

  public void start(BundleContext context)
    throws Exception
  {
    super.start(context);
    JSModelAdapterFactory.register(Platform.getAdapterManager());
  }

  protected void initializeDefaultPreferences(IPreferenceStore store)
  {
    store.setDefault("autoOutline", true);

    store.setDefault("commentColor", "63,127,95");
    store.setDefault("stringColor", "42,0,255");
    store.setDefault("keywordColor", "127,0,85");
    store.setDefault("defaultColor", "0,0,0");
  }

  protected void initializeImageRegistry(ImageRegistry reg)
  {
    JSImages.initializeRegistry(reg);
  }
}