package net.sf.wdte.js.ui.preferences;

import net.sf.wdte.js.ui.JSUIPlugin;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

public class JavaScriptPreferencePage extends FieldEditorPreferencePage
  implements IWorkbenchPreferencePage, PreferenceNames
{
  public JavaScriptPreferencePage()
  {
    super(1);
    setPreferenceStore(JSUIPlugin.getDefault().getPreferenceStore());
    setDescription("Preferences for JavaScript editor.");
  }

  public void createFieldEditors()
  {
    addField(new BooleanFieldEditor("autoOutline", "&Automatic Outlining", getFieldEditorParent()));
    addField(new ColorFieldEditor("commentColor", "&Comment Color:", getFieldEditorParent()));
    addField(new ColorFieldEditor("stringColor", "&String Color:", getFieldEditorParent()));
    addField(new ColorFieldEditor("keywordColor", "&Keyword Color:", getFieldEditorParent()));
    addField(new ColorFieldEditor("defaultColor", "D&efault Color:", getFieldEditorParent()));
  }

  public void init(IWorkbench workbench)
  {
  }
}