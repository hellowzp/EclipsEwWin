package net.sf.wdte.js.ui.preferences;

public abstract interface PreferenceNames
{
  public static final String P_COMMENT_COLOR = "commentColor";
  public static final String P_STRING_COLOR = "stringColor";
  public static final String P_KEYWORD_COLOR = "keywordColor";
  public static final String P_DEFAULT_COLOR = "defaultColor";
  public static final String P_AUTO_OUTLINE = "autoOutline";
}