package ui;

public interface RealTimeDisplay {
	void updateDisplay();
}
