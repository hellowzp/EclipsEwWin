package ui;

import javax.swing.JPanel;

public class Report extends JPanel{

	private static final long serialVersionUID = 1L;

}
