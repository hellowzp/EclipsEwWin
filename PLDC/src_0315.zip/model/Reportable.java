package model;

public interface Reportable {

	void generateReport();
	
}
