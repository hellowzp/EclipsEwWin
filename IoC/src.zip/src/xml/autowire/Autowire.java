package xml.autowire;


public interface Autowire {

	
	String getValue();
}
