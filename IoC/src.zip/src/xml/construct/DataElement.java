package xml.construct;


public interface DataElement {

	
	String getType();
	
	
	Object getValue();
}
