package xml.exception;


public class ElementLoaderException extends RuntimeException {

	public ElementLoaderException(String s) {
		super(s);
	}
}
