package context.exception;


public class PropertyException extends RuntimeException {

	public PropertyException(String s) {
		super(s);
	}
}
