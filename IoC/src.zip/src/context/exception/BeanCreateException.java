package context.exception;


public class BeanCreateException extends RuntimeException {

	public BeanCreateException(String e) {
		super(e);
	}
}
