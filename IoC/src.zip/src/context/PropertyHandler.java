package context;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import xml.property.PropertyElement;


public interface PropertyHandler {

	
	Object setProperties(Object obj, Map<String, Object> properties);
	
//	
//	List<String> getSetterMethodName(Map<String, Object> properties);
	
	
	Map<String, Method> getSetterMethodsMap(Object obj);
	
	
	void executeMethod(Object object, Object argBean, Method method);

	
}
